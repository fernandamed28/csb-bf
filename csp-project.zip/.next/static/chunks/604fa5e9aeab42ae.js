__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e60471e3b418eb79.js",
  "static/chunks/turbopack-7d039c2f22f9a744.js"
])
