globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/e60471e3b418eb79.js",
      "static/chunks/turbopack-7d039c2f22f9a744.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/e60471e3b418eb79.js",
      "static/chunks/turbopack-67561c2e0f03d75b.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/c85a7d07e7b82c9a.js",
    "static/chunks/5564f493499345f1.js",
    "static/chunks/150316a471952cee.js",
    "static/chunks/3e0f93b37bf948e9.js",
    "static/chunks/turbopack-7e8840ea68700fe4.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];