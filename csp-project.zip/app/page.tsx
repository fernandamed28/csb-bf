"use client";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import styles from "./Home.module.css";
import Image from "next/image";



const posts = [
  {
    id: 1,
    title: "Lancement du nouveau programme syndical",
    excerpt: "Découvrez les grandes lignes du nouveau programme CSB pour 2025 et les ambitions portées par l’organisation.",
    image: "/blog1.jpg",
    date: "2025-10-01",
    author: "A. Ouédraogo",
  },
  {
    id: 2,
    title: "Retour sur l’atelier régional de Ouaga",
    excerpt: "Synthèse des échanges, recommandations et perspectives issues de l’atelier régional du 15 septembre.",
    image: "/blog2.jpg",
    date: "2025-09-15",
    author: "M. Sawadogo",
  },
  {
    id: 3,
    title: "CSB lance sa plateforme digitale",
    excerpt: "Un nouvel outil pour suivre les activités, rapports et annonces de la confédération en temps réel.",
    image: "/blog3.jpg",
    date: "2025-09-05",
    author: "S. Kaboré",
  },
];

export default function Home() {
  return (
    <>
      <Header />
      <main className={styles.main}>
        {/* Hero */}
        <section id="hero" className={styles.hero}>
          <div className={styles.heroContent}>
            <h1>
              Bienvenue sur le <span>blog</span> de la CSB
            </h1>
            <p>
              Actualités, analyses, annonces et vie de l’organisation.<br />
              Suivez toute l’actualité syndicale et sociale.
            </p>
            <a href="#blog" className={styles.ctaBtn}>
              Voir les articles
            </a>
          </div>
        </section>

        {/* Blog Cards */}
        <section id="blog" className={styles.blogSection}>
          <h2 className={styles.sectionTitle}>Derniers articles</h2>
          <div className={styles.cardsGrid}>
            {posts.map((post) => (
              <article className={styles.card} key={post.id}>
                <div className={styles.cardImgWrapper}>
                  <Image
                    src={post.image}
                    alt={post.title}
                    className={styles.cardImg}
                    width={400}
                    height={200}
                    style={{ objectFit: "cover", width: "100%", height: "100%" }}
                    priority={post.id === 1}
                  />
                </div>
                <div className={styles.cardBody}>
                  <div className={styles.cardMeta}>
                    <span>{new Date(post.date).toLocaleDateString("fr-FR")}</span>
                    <span>• {post.author}</span>
                  </div>
                  <h3 className={styles.cardTitle}>{post.title}</h3>
                  <p className={styles.cardExcerpt}>{post.excerpt}</p>
                  <a href="#" className={styles.cardLink}>
                    Lire l’article
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        {/* About */}
        <section id="about" className={styles.aboutSection}>
          <div className={styles.aboutContent}>
            <h2>À propos de la CSB</h2>
            <p>
              La Confédération Syndicale Burkinabè (CSB) défend les droits des travailleurs, promeut le dialogue social et l’innovation syndicale au Burkina Faso.
            </p>
            <ul>
              <li>Actualité syndicale et sociale</li>
              <li>Analyses et dossiers</li>
              <li>Vie de l’organisation</li>
              <li>Plateforme ouverte à tous les membres</li>
            </ul>
          </div>
          <Image
              src="/about.jpg"
              alt="À propos"
              className={styles.aboutImg}
              width={320}
              height={220}
              style={{ borderRadius: 18, boxShadow: "0 4px 24px rgba(25,118,210,0.08)" }}
            />
        </section>
      </main>
      <Footer />
    </>
  );
}